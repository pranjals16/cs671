#!/usr/bin/python
# -*- coding: utf-8 -*-

import nltk
sentence = """मुख्य प्रांजल  हूं"""
tokens = nltk.word_tokenize(sentence)
print tokens
